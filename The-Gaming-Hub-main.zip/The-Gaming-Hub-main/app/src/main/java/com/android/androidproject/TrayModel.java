package com.android.androidproject;

public class TrayModel {
    private String gamePic;

    public TrayModel(){}

    public TrayModel(String gamePic){
        this.gamePic=gamePic;
    }

    public String getGamePic(){return gamePic;}
}
